"""Normalized camera registry domain."""
