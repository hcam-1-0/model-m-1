"""Audit event foundation."""
