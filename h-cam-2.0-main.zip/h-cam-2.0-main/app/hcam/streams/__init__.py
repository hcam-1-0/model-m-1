"""Video stream management domain."""
