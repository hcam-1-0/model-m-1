"""Authentication and authorization boundary."""
